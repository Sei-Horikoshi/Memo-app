class Category < ApplicationRecord
    has_many :memos
end
