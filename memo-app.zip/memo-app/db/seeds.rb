Category.find_or_create_by(name:"仕事")
Category.find_or_create_by(name:"趣味")
Category.find_or_create_by(name:"生活")
Category.find_or_create_by(name:"その他")